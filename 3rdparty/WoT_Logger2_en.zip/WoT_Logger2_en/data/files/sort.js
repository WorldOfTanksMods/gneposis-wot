﻿//var default_sort = $(".js-sort-tbl");
var sortUp = false;

$(document).ready(
	function() {
		$(".js-sort-btn").click(
				function() {
					var RegEx=/\d*\[/;
					var RegEx1=/I|II|III|IV|V|VI|VII|VIII|XI|X/g;
					var index = $(this).parent().index();
					var tr = $(".js-sort-tbl tr");
					var ttt = true;
					while(ttt) {
						ttt = false;
						for(var i = 0; i < tr.length - 1; i++){
							var sa = tr.eq(i).children("td").eq(index).text().replace(/\s/g,"").replace(RegEx,"").replace(RegEx1,"");
							var sb = tr.eq(i+1).children("td").eq(index).text().replace(/\s/g,"").replace(RegEx,"").replace(RegEx1,"");
							var a = (isNaN(parseFloat(sa)))?sa:parseFloat(sa);
							var b = (isNaN(parseFloat(sb)))?sb:parseFloat(sb);
							if (((a > b) & !sortUp) | ((a < b) & sortUp)) {
								tr.eq(i+1).insertBefore(tr.eq(i));
								tr = $(".js-sort-tbl tr");
								ttt = true;
							}
						}
					}
					sortUp =!sortUp;
				});
	});