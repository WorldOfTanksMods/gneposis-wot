﻿var fNation = {'ussr':true,'germany':true,'china':true,'france':true,'usa':true};
var fLevels = {'I':true,'II':true,'III':true,'IV':true,'V':true,'VI':true,'VII':true,'VIII':true,'IX':true,'X':true};
var fTypes = {'li':true,'me':true,'he':true,'AT':true,'SP':true};
var fRates = {'noob':true,'avrnoob':true,'avr':true,'good':true,'great':true,'unicum':true};
$(document).ready(
	function() {
		var levelActive, nationActive, typeActive, rateActive;
	
		$(".nations").click(
			function() {
				var itemsTr = $(".tankrow");				
				var nationId = $(this).attr("id");			
				
				$(this).attr("src", function() { 
					var link = $(this).attr("src");
					if (fNation[nationId]) {
						fNation[nationId] = false;
						return link=link.replace("color", "gray"); 
					} else {
						fNation[nationId] = true;
						return link=link.replace("gray", "color"); 
					}
				});
				
				Show_Hide_Tr(itemsTr);			
			});
			
		$(".levels").click(
			function() {
				var itemsTr = $(".tankrow");				
				var levelId = $(this).attr("id");
				
				$(this).attr("src", function() { 
					var link = $(this).attr("src");
					if (fLevels[levelId]) {
						fLevels[levelId] = false;
						return link=link.replace("color", "gray"); 
					} else {
						fLevels[levelId] = true;
						return link=link.replace("gray", "color"); 
					}
				});						
				
				Show_Hide_Tr(itemsTr);	
			});
			
		$(".types").click(
			function() {
				var itemsTr = $(".tankrow");				
				var typeId = $(this).attr("id");
				
				$(this).attr("src", function() { 
					var link = $(this).attr("src");
					if (fTypes[typeId]) {
						fTypes[typeId] = false;
						return link=link.replace("color", "gray"); 
					} else {
						fTypes[typeId] = true;
						return link=link.replace("gray", "color"); 
					}
				});						
				
				Show_Hide_Tr(itemsTr);	
			});
			
		$(".rates").click(
			function() {
				var itemsTr = $(".tankrow");				
				var rateId = $(this).attr("id");
				
				$(this).attr("src", function() { 
					var link = $(this).attr("src");
					if (fRates[rateId]) {
						fRates[rateId] = false;
						return link=link.replace("color", "gray"); 
					} else {
						fRates[rateId] = true;
						return link=link.replace("gray", "color"); 
					}
				});						
				
				Show_Hide_Tr(itemsTr);	
			});
		
		function Show_Hide_Tr (itemsTr) {
			itemsTr.each(function(){	
							var itemTdNation = $(this).find(" > td.th-stat-1").attr("abbr");
							var itemTdLevel = $(this).find(" > td.th-stat-1 > div.wrapper > span.level").html();
							var itemTdType = $(this).attr("abbr");
							var itemTdRate = $(this).find(" > td.th-stat-8 > div").attr("class");
							if (fNation[itemTdNation] && fLevels[itemTdLevel] && fTypes[itemTdType] && fRates[itemTdRate]) {
								$(this).show();
							} else {
								$(this).hide();
							}
						});
		}
		
		$(".fPoint > img").hover(
			function() {
				$(this).attr("src", function() {
					var link = $(this).attr("src");
					return link=link.replace("gray", "color"); 
				});
			},
			function() {
				$(this).attr("src", function() {
					var link = $(this).attr("src");
					return link=link.replace("color", "gray"); 
				});
			});
			
		$(".fPoint > img").click(
			function() {
				var itemParent = $(this).parent().attr("id");
				var blockParent = $(this).parent().parent().attr("class");
				
				if ( $(this).attr("class") == "fPoint-all") {
					$.each(eval(itemParent), function(key, value){
						eval(itemParent + "['" + key + "'] = true");
					});
					$("." + blockParent + " > img").attr("src", function() {
						var link = $(this).attr("src");
						return link=link.replace("gray", "color"); 
					});
				}else{
					$.each(eval(itemParent), function(key, value){
						eval(itemParent + "['" + key + "'] = false");
					});								
					$("." + blockParent + " > img").attr("src", function() {
						var link = $(this).attr("src");
						return link=link.replace("color", "gray"); 
					});
				}
				
				Show_Hide_Tr($(".tankrow"));	
			});
	});