﻿var chartID="dmgchart"; 
$(document).ready(
	function() {
		$(".d-chart-nav img").click(
			function() {			
				if ($(this).attr("id") != chartID) {
					var items = $(".d-chart-nav img");
					items.each(
						function(){
							$(this).attr("src", function() {
								var link = $(this).attr("src");
								link=link.replace("_gray", "");
								return link=link.replace(".png", "_gray.png");
							});		
						});

					$(this).attr("src", function() {
						var link = $(this).attr("src");
						return link=link.replace("_gray", "");
					});	

					chartID = $(this).attr("id");
					
					$(".d-chart-main div").hide();					
					$(".d-chart-main div#"+chartID+"_div").show();
				}
			});
	});