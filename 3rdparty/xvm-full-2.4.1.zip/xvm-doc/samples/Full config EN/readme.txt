﻿Config with all possible settings set to default values.
With english comments
