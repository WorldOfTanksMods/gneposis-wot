This configuration contains some clan icons for clans from the european server and changes positioning, so they don't overlap the contour icons any more.
It also disables mirroring of vehicle icons, postmortem tips at the bottom of the screen and the PanelsModeSwitcher above the left PlayersPanel.
It activates player statistics in all battle types and makes PlayersPanels more transparent.


Location of the XVM.xvmconf:      World_of_Tanks\res_mods\[GAME_VERSION]\gui\flash