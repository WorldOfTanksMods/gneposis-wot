﻿Config with all possible settings except players statistics set to default values.
With english comments
