﻿Русский:
  Два варианта конфигов, приближенных к стандартному маркеру в клиенте.
  Автор: sfedu

English:
  Two variants of configs like standard client marker.
  Author: sfedu
